declare module 'daisyui';
